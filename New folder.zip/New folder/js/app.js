(function(){
  const SUPABASE_URL = 'https://palrtkdvdtkqmvkjfuud.supabase.co';
  const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InBhbHJ0a2R2ZHRrcW12a2pmdXVkIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODUwOTEyMjQsImV4cCI6MjEwMDY2NzIyNH0.5gYn9PvkMZFk922qULn4GmCQvgUnHeiES4mSEVe5q0w';
  const db = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY,{auth:{persistSession:true,autoRefreshToken:true,detectSessionInUrl:true}});
  const $=id=>document.getElementById(id);
  let inventory=[],categories=[],distributors=[],categoryRecords=[],distributorRecords=[],adminUsers=[],manageState=null,currentUser=null,userRole='staff',channel=null,currentEditId=null,pendingBarcode=null,scanMode='edit',quickProduct=null,authMode='signin',html5QrCode=null,camRunning=false,panelQrCode=null,panelCameraRunning=false,historyPage=1,historyTotal=0;
  const money=new Intl.NumberFormat('en-US',{style:'currency',currency:'USD'});
  function showAuthMessage(message,type='error'){$('authError').textContent=message;$('authError').className='auth-error'+(type==='success'?' success':type==='info'?' info':'')}
  function setAuthMode(m){authMode=m;const s=m==='signin';$('authSignInTab').className='btn '+(s?'btn-ink':'btn-line');$('authSignUpTab').className='btn '+(!s?'btn-ink':'btn-line');$('authSubmit').textContent=s?'Sign in':'Create account';$('authConfirmWrap').classList.toggle('visible',!s);$('authPassword').autocomplete=s?'current-password':'new-password';$('authConfirmPassword').value='';showAuthMessage('','info')}
  $('authSignInTab').onclick=()=>setAuthMode('signin');
  $('authSignUpTab').onclick=()=>setAuthMode('signup');
  $('authSubmit').onclick=async()=>{const email=$('authEmail').value.trim(),password=$('authPassword').value,confirmPassword=$('authConfirmPassword').value,button=$('authSubmit');showAuthMessage('','info');if(!email||password.length<6)return showAuthMessage('Enter a valid email and a password with at least 6 characters.');if(authMode==='signup'&&password!==confirmPassword)return showAuthMessage('Passwords do not match. Please enter the same password twice.');button.disabled=true;button.textContent=authMode==='signin'?'Signing in…':'Creating account…';try{if(authMode==='signin'){const {error}=await db.auth.signInWithPassword({email,password});if(error)showAuthMessage(error.message)}else{const redirectTo=window.location.origin+window.location.pathname;const {data,error}=await db.auth.signUp({email,password,options:{emailRedirectTo:redirectTo}});if(error)return showAuthMessage(error.message);$('authPassword').value='';$('authConfirmPassword').value='';if(data.session){showAuthMessage('Account created successfully. Email verification is currently not required, so you have been signed in.','success')}else{showAuthMessage(`Verification email sent to ${email}. Open the email and click the confirmation link before signing in.`,'success')}}}catch(error){showAuthMessage(error?.message||'Authentication failed. Please try again.')}finally{button.disabled=false;button.textContent=authMode==='signin'?'Sign in':'Create account'}};
  $('authPassword').addEventListener('keydown',e=>{if(e.key==='Enter')$('authSubmit').click()});
  $('authConfirmPassword').addEventListener('keydown',e=>{if(e.key==='Enter')$('authSubmit').click()});
  $('signOutBtn').onclick=()=>db.auth.signOut();
  async function applySession(session){currentUser=session?.user||null;$('authOverlay').classList.toggle('hidden',!!currentUser);$('signOutBtn').style.display=currentUser?'block':'none';$('userEmail').textContent=currentUser?.email||'';if(currentUser){await loadRole();subscribe();await loadInventory()}else{inventory=[];userRole='staff';document.body.classList.remove('is-admin');sync('Offline')}}
  db.auth.onAuthStateChange((e,s)=>applySession(s));
  db.auth.getSession().then(({data})=>applySession(data.session)).catch(error=>showAuthMessage(error?.message||'Unable to restore session.'));
  const views={scan:$('view-scan'),inventory:$('view-inventory'),export:$('view-export'),admin:$('view-admin')};
  const navBtns=[...document.querySelectorAll('.navbtn')];
  const isAdmin=()=>userRole==='admin';
  const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  function toast(msg){const t=$('toast');t.textContent=msg;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),1800)}
  function sync(text,error=false){$('syncState').textContent=text;$('syncState').style.color=error?'var(--rust)':'var(--green)'}
  function normalizeBarcode(v){return String(v??'').trim().replace(/\.0$/,'')}
  function sameBarcode(a,b){const x=normalizeBarcode(a),y=normalizeBarcode(b);return x===y||x.replace(/^0+/,'')===y.replace(/^0+/,'')}
  function fromDb(r){return{id:r.id,barcode:r.barcode,name:r.name,price:r.price==null?null:Number(r.price),cost:r.cost==null?null:Number(r.cost),category:r.category||'',distributor:r.distributor||'',floorQty:r.floor_qty||0,backroomQty:r.backroom_qty||0,backroomCases:r.backroom_cases||0,unitsPerCase:r.units_per_case||0,lowStockThreshold:r.low_stock_threshold||0,lowStockAlertEnabled:r.low_stock_alert_enabled!==false,status:r.status||'in_stock',updatedAt:new Date(r.updated_at).getTime(),updatedBy:r.updated_by}}
  const caseUnits=p=>(p.backroomCases||0)*(p.unitsPerCase||0);
  const totalUnits=p=>(p.floorQty||0)+(p.backroomQty||0)+caseUnits(p);
  function switchView(name){if(name==='admin'&&!isAdmin())name='scan';Object.entries(views).forEach(([k,v])=>v&&v.classList.toggle('active',k===name));navBtns.forEach(b=>b.classList.toggle('active',b.dataset.view===name));if(name==='inventory')renderList();if(name==='export')renderStats();if(name==='admin')renderAdmin();if(name==='scan')clearScanSearch()}
  navBtns.forEach(b=>b.addEventListener('click',()=>switchView(b.dataset.view)));
  function applyRoleUI(){document.body.classList.toggle('is-admin',isAdmin());$('roleChip').style.display='inline-block';$('roleChip').textContent=isAdmin()?'ADMIN':'STAFF';$('addCategoryBtn').style.display=isAdmin()?'block':'none';$('addDistributorBtn').style.display=isAdmin()?'block':'none'}
  async function loadRole(){userRole='staff';if(!currentUser)return;const {data,error}=await db.from('profiles').select('role').eq('id',currentUser.id).maybeSingle();if(!error&&data?.role)userRole=data.role;applyRoleUI()}
  function fillSelect(id,vals,selected,label){const el=$(id);if(!el)return;const clean=[...new Set((vals||[]).filter(Boolean))].sort((a,b)=>a.localeCompare(b));el.innerHTML=`<option value="">${esc(label)}</option>`+clean.map(v=>`<option value="${esc(v)}">${esc(v)}</option>`).join('');if(selected&&!clean.includes(selected))el.insertAdjacentHTML('beforeend',`<option value="${esc(selected)}">${esc(selected)}</option>`);el.value=selected||''}
  async function loadLists(){
    const [a,b,c,d]=await Promise.all([
      db.from('categories').select('id,name,active,created_at').order('name'),
      db.from('distributors').select('id,name,active,created_at').order('name'),
      db.from('inventory').select('category,distributor'),
      db.from('product_catalog').select('category,distributor')
    ]);
    categoryRecords=(a.data||[]).map(x=>({...x,active:x.active!==false}));
    distributorRecords=(b.data||[]).map(x=>({...x,active:x.active!==false}));
    const activeCats=categoryRecords.filter(x=>x.active).map(x=>x.name), activeDists=distributorRecords.filter(x=>x.active).map(x=>x.name);
    categories=[...new Set(activeCats.filter(Boolean))];
    distributors=[...new Set(activeDists.filter(Boolean))];
    fillSelect('fieldCategory',categories,$('fieldCategory').value,'Uncategorized');
    fillSelect('fieldDistributor',distributors,$('fieldDistributor').value,'Not assigned');
    fillSelect('reportCategory',categories,$('reportCategory')?.value,'All categories');
    fillSelect('reportDistributor',distributors,$('reportDistributor')?.value,'All distributors');
    fillSelect('inventoryCategoryFilter',categories,$('inventoryCategoryFilter')?.value,'All categories');
  }
  async function loadInventory(){if(!currentUser)return;sync('Syncing…');const {data,error}=await db.from('inventory').select('*').order('updated_at',{ascending:false});if(error){sync('Sync failed',true);toast(error.message);return}inventory=(data||[]).map(fromDb);await loadLists();$('headerCount').textContent=`${inventory.length} item${inventory.length===1?'':'s'}`;renderList();renderStats();if(isAdmin())await renderAdmin();sync('Live')}
  function subscribe(){if(channel)db.removeChannel(channel);channel=db.channel('inventory-live').on('postgres_changes',{event:'*',schema:'public',table:'inventory'},()=>loadInventory()).subscribe()}
  function findProduct(code){return inventory.find(p=>sameBarcode(p.barcode,code))}
  async function lookupCatalog(code){const exact=normalizeBarcode(code);let {data,error}=await db.from('product_catalog').select('barcode,product_name,price,cost,category,distributor').eq('barcode',exact).maybeSingle();if(error)throw error;if(!data){const stripped=exact.replace(/^0+/,'');if(stripped!==exact){({data,error}=await db.from('product_catalog').select('barcode,product_name,price,cost,category,distributor').eq('barcode',stripped).maybeSingle());if(error)throw error}}return data}
  function setMode(mode){scanMode=mode;document.querySelectorAll('.mode-btn').forEach(b=>b.classList.toggle('active',b.dataset.mode===mode));$('modeHelp').textContent=mode==='edit'?'Scan to open and edit a product.':mode==='receive'?'Scan an existing product and add received units.':'Scan an existing product and remove sold, damaged, or transferred units.';$('quickAdjust').classList.remove('active');quickProduct=null}
  document.querySelectorAll('.mode-btn').forEach(b=>b.addEventListener('click',()=>setMode(b.dataset.mode)));
  function clearScanSearch(){
    const input=$('scanProductSearch'),results=$('scanSearchResults');
    if(input)input.value='';
    if(results)results.innerHTML='';
  }
  function openQuickAdjust(p){
    quickProduct=p;
    $('quickProductName').textContent=p.name;
    $('quickProductMeta').textContent=`${p.barcode} · ${totalUnits(p)} units on hand · ${p.backroomCases} unopened case${p.backroomCases===1?'':'s'}`;
    $('quickQty').value=1;
    $('quickLocation').value='floor';
    $('quickAdjustError').textContent='';
    updateQuickAdjustSummary();
    $('quickAdjust').classList.add('active');
    $('quickAdjust').scrollIntoView({behavior:'smooth',block:'nearest'});
  }
  async function handleScan(raw){
    const code=normalizeBarcode(raw);
    if(!code)return;
    clearScanSearch();
    let p=findProduct(code);
    if(!p){
      const {data,error}=await db.from('inventory').select('*').eq('barcode',code).maybeSingle();
      if(!error&&data)p=fromDb(data);
    }
    if(scanMode!=='edit'){
      if(!p){toast('Add this product to inventory before receiving or removing stock');pendingBarcode=code;openPanel(null,true);return;}
      openQuickAdjust(p);return;
    }
    if(p){openPanel(p);return;}
    pendingBarcode=code;openPanel(null,true);
  }
  function updateQuickAdjustSummary(){
    if(!quickProduct)return;
    const qty=Math.max(1,parseInt($('quickQty').value||1,10));
    const loc=$('quickLocation').value;
    const isCases=loc==='cases';
    const unitsPerCase=quickProduct.unitsPerCase||0;
    const available=loc==='floor'?quickProduct.floorQty:loc==='backroom'?quickProduct.backroomQty:quickProduct.backroomCases;
    $('quickQtyLabel').textContent=isCases?(scanMode==='receive'?'Cases to receive':'Cases to remove'):(scanMode==='receive'?'Units to receive':'Units to remove');
    $('quickApply').textContent=scanMode==='receive'?'Receive':'Remove';
    $('quickAdjustError').textContent='';
    if(isCases){
      $('quickAdjustSummary').textContent=unitsPerCase>0?`${qty} case${qty===1?'':'s'} × ${unitsPerCase} bottles = ${qty*unitsPerCase} bottles. Available: ${available} case${available===1?'':'s'}.`:'Bottles per case is missing. Edit the product before adjusting unopened cases.';
    }else{
      const label=loc==='floor'?'on floor':'open back room';
      $('quickAdjustSummary').textContent=`${scanMode==='receive'?'+':'−'}${qty} bottle${qty===1?'':'s'} ${label}. Available: ${available}.`;
    }
  }
  $('quickLocation').addEventListener('change',updateQuickAdjustSummary);
  $('quickQty').addEventListener('input',updateQuickAdjustSummary);
  $('quickQtyMinus').addEventListener('click',()=>{$('quickQty').value=Math.max(1,(parseInt($('quickQty').value||1,10)-1));updateQuickAdjustSummary()});
  $('quickQtyPlus').addEventListener('click',()=>{$('quickQty').value=Math.max(1,(parseInt($('quickQty').value||1,10)+1));updateQuickAdjustSummary()});
  $('quickCancel').addEventListener('click',()=>{$('quickAdjust').classList.remove('active');quickProduct=null;clearScanSearch()});
  $('quickApply').addEventListener('click',async()=>{
    if(!quickProduct)return;
    const qty=Math.max(1,parseInt($('quickQty').value||1,10)),loc=$('quickLocation').value,sign=scanMode==='receive'?1:-1;
    const available=loc==='floor'?quickProduct.floorQty:loc==='backroom'?quickProduct.backroomQty:quickProduct.backroomCases;
    if(loc==='cases'&&!(quickProduct.unitsPerCase>0)){$('quickAdjustError').textContent='Bottles per case is required before unopened cases can be adjusted.';return;}
    if(sign<0&&qty>available){$('quickAdjustError').textContent=`Cannot remove ${qty}. Only ${available} ${loc==='cases'?'case(s)':'unit(s)'} are available at this location.`;return;}
    const updates={};
    if(loc==='floor')updates.floor_qty=quickProduct.floorQty+sign*qty;
    if(loc==='backroom')updates.backroom_qty=quickProduct.backroomQty+sign*qty;
    if(loc==='cases')updates.backroom_cases=quickProduct.backroomCases+sign*qty;
    updates.status=((updates.floor_qty??quickProduct.floorQty)+(updates.backroom_qty??quickProduct.backroomQty)+((updates.backroom_cases??quickProduct.backroomCases)*quickProduct.unitsPerCase)>0)?'in_stock':'out_of_stock';
    updates.updated_by=currentUser.id;updates.updated_at=new Date().toISOString();
    const {error}=await db.from('inventory').update(updates).eq('id',quickProduct.id);
    if(error){$('quickAdjustError').textContent=error.message;return;}
    const bottleChange=loc==='cases'?sign*qty*quickProduct.unitsPerCase:sign*qty;
    await db.from('inventory_history').insert({inventory_id:quickProduct.id,barcode:quickProduct.barcode,product_name:quickProduct.name,action:scanMode,location:loc,quantity_change:bottleChange,changed_by:currentUser.id});
    toast(`${scanMode==='receive'?'Received':'Removed'} ${qty} ${loc==='cases'?'case(s)':'unit(s)'}`);
    $('quickAdjust').classList.remove('active');quickProduct=null;clearScanSearch();await loadInventory();
  });

  let searchTimer=null,searchSequence=0;
  async function searchCatalogAndInventory(term){
    const q=term.trim();
    const results=$('scanSearchResults');
    if(q.length<2){results.innerHTML='';return;}
    const sequence=++searchSequence;
    const lower=q.toLowerCase();
    const live=inventory.filter(p=>[p.name,p.barcode,p.category,p.distributor].some(v=>String(v||'').toLowerCase().includes(lower))).slice(0,8);
    let catalog=[];
    try{
      const safe=q.replace(/[%_,()]/g,' ');
      const {data,error}=await db.from('product_catalog').select('barcode,product_name,price,cost,category,distributor').or(`product_name.ilike.%${safe}%,barcode.ilike.%${safe}%`).limit(12);
      if(!error)catalog=data||[];
    }catch(_error){}
    if(sequence!==searchSequence)return;
    const liveCodes=new Set(live.map(p=>normalizeBarcode(p.barcode)));
    const catalogOnly=catalog.filter(c=>!liveCodes.has(normalizeBarcode(c.barcode))).slice(0,8);
    const items=[...live.map(p=>({type:'inventory',barcode:p.barcode,name:p.name,category:p.category,product:p})),...catalogOnly.map(c=>({type:'catalog',barcode:c.barcode,name:c.product_name,category:c.category,catalog:c}))].slice(0,12);
    results.innerHTML=items.length?items.map((item,index)=>`<button type="button" class="scan-search-result" data-search-index="${index}"><span><strong>${esc(item.name||'Unnamed product')}</strong><small>${esc(item.barcode)}${item.category?' · '+esc(item.category):''}</small></span><em>${item.type==='inventory'?'In inventory':'Catalog'}</em></button>`).join(''):`<div class="scan-search-empty">No matching product. Press Enter to add “${esc(q)}” manually.</div>`;
    results.querySelectorAll('[data-search-index]').forEach(button=>button.onclick=()=>selectSearchResult(items[Number(button.dataset.searchIndex)]));
  }
  function selectSearchResult(item){
    clearScanSearch();
    if(item.type==='inventory'){
      if(scanMode==='edit')openPanel(item.product);else openQuickAdjust(item.product);
      return;
    }
    if(scanMode!=='edit'){toast('This catalog product must be added to inventory first');}
    const c=item.catalog;
    pendingBarcode=normalizeBarcode(c.barcode);
    openPanel(null,false);
    $('fieldName').value=c.product_name||'';$('fieldPrice').value=c.price??'';$('fieldCost').value=c.cost??'';
    fillSelect('fieldCategory',categories,c.category||'','Uncategorized');fillSelect('fieldDistributor',distributors,c.distributor||'','Not assigned');
    $('lookupStatus').textContent='Loaded from imported catalog';$('lookupStatus').classList.add('found');
  }
  $('scanProductSearch').addEventListener('input',e=>{clearTimeout(searchTimer);searchTimer=setTimeout(()=>searchCatalogAndInventory(e.target.value),180)});
  $('scanProductSearch').addEventListener('keydown',e=>{
    if(e.key!=='Enter')return;e.preventDefault();
    const first=$('scanSearchResults').querySelector('[data-search-index]');
    if(first){first.click();return;}
    const value=e.currentTarget.value.trim();if(!value)return;
    if(/^\d{6,}$/.test(value))handleScan(value);else{pendingBarcode='';openPanel(null,false);$('fieldName').value=value;clearScanSearch();}
  });

  let scannerBuffer='',scannerLastKey=0,scannerResetTimer=null;
  document.addEventListener('keydown',event=>{
    if(!currentUser||!views.scan.classList.contains('active'))return;
    if($('panelOverlay').classList.contains('active')||$('quickAdjust').classList.contains('active'))return;
    const target=event.target;
    if(target&&(['INPUT','TEXTAREA','SELECT'].includes(target.tagName)||target.isContentEditable))return;
    const now=Date.now();
    if(now-scannerLastKey>120)scannerBuffer='';
    scannerLastKey=now;
    if(event.key==='Enter'){
      const code=scannerBuffer;scannerBuffer='';clearTimeout(scannerResetTimer);
      if(code.length>=6){event.preventDefault();handleScan(code)}
      return;
    }
    if(event.key.length===1){scannerBuffer+=event.key;clearTimeout(scannerResetTimer);scannerResetTimer=setTimeout(()=>scannerBuffer='',180)}
  });
  let lookupSeq=0;
  function openPanel(p,auto=false){currentEditId=p?.id||null;$('panelTitle').textContent=p?'Edit product':'Add product';$('panelBarcode').textContent=p?.barcode||'New item';$('fieldBarcode').value=p?.barcode||pendingBarcode||'';$('fieldName').value=p?.name||'';$('fieldPrice').value=p?.price??'';$('fieldCost').value=p?.cost??'';fillSelect('fieldCategory',categories,p?.category||'','Uncategorized');fillSelect('fieldDistributor',distributors,p?.distributor||'','Not assigned');$('fieldFloorQty').value=p?.floorQty??0;$('fieldBackQty').value=p?.backroomQty??0;$('fieldCases').value=p?.backroomCases??0;$('fieldUnitsPerCase').value=p?.unitsPerCase??0;$('fieldLowStockEnabled').checked=p?p.lowStockAlertEnabled:true;$('fieldLowStock').value=p?p.lowStockThreshold:1;syncLowStockFields();$('panelDelete').style.display=p&&isAdmin()?'block':'none';$('panelOverlay').classList.add('active');$('lookupStatus').textContent='';updateTotal();if(auto)runLookup($('fieldBarcode').value)}
  async function runLookup(code){const seq=++lookupSeq;$('lookupStatus').textContent='Looking up imported catalog…';try{const d=await lookupCatalog(code);if(seq!==lookupSeq||currentEditId)return;if(d){$('fieldName').value=d.product_name||'';$('fieldPrice').value=d.price??'';$('fieldCost').value=d.cost??'';fillSelect('fieldCategory',categories,d.category||'','Uncategorized');fillSelect('fieldDistributor',distributors,d.distributor||'','Not assigned');$('lookupStatus').textContent='Found in imported catalog';$('lookupStatus').classList.add('found')}else $('lookupStatus').textContent='No catalog match — enter details manually'}catch(e){$('lookupStatus').textContent=`Catalog error: ${e.message}`}}
  function updateTotal(){const f=+$('fieldFloorQty').value||0,b=+$('fieldBackQty').value||0,c=+$('fieldCases').value||0,u=+$('fieldUnitsPerCase').value||0;$('totalLine').textContent=`Total on hand: ${f+b+c*u} units · ${c} unopened case${c===1?'':'s'}`}
  function syncLowStockFields(){$('lowStockThresholdWrap').classList.toggle('disabled',!$('fieldLowStockEnabled').checked)}
  $('fieldLowStockEnabled').onchange=syncLowStockFields;
  function initializeQuantityButtons(){
    document.querySelectorAll('[data-quantity-target]').forEach(button=>{
      button.addEventListener('click',()=>{
        const input=$(button.dataset.quantityTarget);
        if(!input)return;
        const change=Number(button.dataset.quantityChange);
        const currentValue=Number(input.value)||0;
        input.value=Math.max(0,currentValue+change);
        input.dispatchEvent(new Event('input',{bubbles:true}));
      });
    });
    ['fieldFloorQty','fieldBackQty','fieldCases','fieldUnitsPerCase'].forEach(id=>{
      $(id).addEventListener('input',updateTotal);
    });
  }
  initializeQuantityButtons();
  async function closePanel(){await stopPanelBarcodeScanner();$('panelOverlay').classList.remove('active');currentEditId=null;pendingBarcode=null}
  async function startPanelBarcodeScanner(){
    const reader=$('panelBarcodeReader'),message=$('panelBarcodeMessage'),button=$('panelScanBarcodeBtn');
    message.style.display='none';message.textContent='';
    if(panelCameraRunning){await stopPanelBarcodeScanner();return;}
    if(typeof Html5Qrcode==='undefined'){message.style.display='block';message.textContent='Barcode camera library did not load.';return;}
    reader.classList.add('active');
    panelQrCode=new Html5Qrcode('panelBarcodeReader');
    try{
      await panelQrCode.start({facingMode:'environment'},{fps:10,qrbox:{width:240,height:140}},async decoded=>{
        $('fieldBarcode').value=normalizeBarcode(decoded);
        $('panelBarcode').textContent=$('fieldBarcode').value||'New item';
        await stopPanelBarcodeScanner();
        runLookup($('fieldBarcode').value);
      },()=>{});
      panelCameraRunning=true;button.textContent='Stop scanner';
    }catch(error){
      reader.classList.remove('active');panelQrCode=null;panelCameraRunning=false;button.textContent='Scan barcode';
      message.style.display='block';message.textContent='Camera unavailable. Type or scan the barcode using the main scanner.';
    }
  }
  async function stopPanelBarcodeScanner(){
    const reader=$('panelBarcodeReader'),button=$('panelScanBarcodeBtn');
    try{if(panelQrCode&&panelCameraRunning)await panelQrCode.stop();}catch(_error){}
    try{if(panelQrCode)panelQrCode.clear();}catch(_error){}
    panelQrCode=null;panelCameraRunning=false;reader.classList.remove('active');reader.innerHTML='';button.textContent='Scan barcode';
  }
  $('panelScanBarcodeBtn').onclick=startPanelBarcodeScanner;
  $('panelCancel').onclick=closePanel;$('panelOverlay').onclick=e=>{if(e.target.id==='panelOverlay')closePanel()};$('manualAddBtn').onclick=()=>openPanel(null);
  async function addList(kind,nameOverride){if(!isAdmin()){toast('Admin access required');return}const label=kind==='category'?'category':'distributor',name=(nameOverride??prompt(`Enter new ${label}:`)??'').trim();if(!name)return;const table=kind==='category'?'categories':'distributors';const {error}=await db.from(table).upsert({name,active:true,created_by:currentUser.id},{onConflict:'name'});if(error){toast(error.message);return}await loadLists();toast(`${label} added`)}
  $('addCategoryBtn').onclick=()=>addList('category');$('addDistributorBtn').onclick=()=>addList('distributor');
  $('panelSave').onclick=async()=>{const product={barcode:normalizeBarcode($('fieldBarcode').value),name:$('fieldName').value.trim(),price:$('fieldPrice').value===''?null:Math.max(0,+$('fieldPrice').value),cost:$('fieldCost').value===''?null:Math.max(0,+$('fieldCost').value),category:$('fieldCategory').value||null,distributor:$('fieldDistributor').value||null,floor_qty:Math.max(0,+$('fieldFloorQty').value||0),backroom_qty:Math.max(0,+$('fieldBackQty').value||0),backroom_cases:Math.max(0,+$('fieldCases').value||0),units_per_case:Math.max(0,+$('fieldUnitsPerCase').value||0),low_stock_threshold:Math.max(0,+$('fieldLowStock').value||0),low_stock_alert_enabled:$('fieldLowStockEnabled').checked,status:((Math.max(0,+$('fieldFloorQty').value||0)+Math.max(0,+$('fieldBackQty').value||0)+(Math.max(0,+$('fieldCases').value||0)*Math.max(0,+$('fieldUnitsPerCase').value||0)))>0?'in_stock':'out_of_stock'),updated_by:currentUser.id,updated_at:new Date().toISOString()};if(!product.barcode||!product.name){toast('Barcode and product name are required');return}if(product.backroom_cases>0&&product.units_per_case<=0){toast('Bottles per case is required when unopened cases are entered');$('fieldUnitsPerCase').focus();return}let error;if(currentEditId){({error}=await db.from('inventory').update(product).eq('id',currentEditId));if(!error)await db.from('inventory_history').insert({inventory_id:currentEditId,barcode:product.barcode,product_name:product.name,action:'edit',location:'all',quantity_change:0,changed_by:currentUser.id})}else{const r=await db.from('inventory').insert(product).select('id').single();error=r.error;if(!error)await db.from('inventory_history').insert({inventory_id:r.data.id,barcode:product.barcode,product_name:product.name,action:'create',location:'all',quantity_change:product.floor_qty+product.backroom_qty+product.backroom_cases*product.units_per_case,changed_by:currentUser.id})}if(error){toast(error.message);return}closePanel();toast('Saved');await loadInventory()};
  $('panelDelete').onclick=async()=>{if(!isAdmin()||!currentEditId)return;const p=inventory.find(x=>x.id===currentEditId);const {error}=await db.from('inventory').delete().eq('id',currentEditId);if(error){toast(error.message);return}await db.from('inventory_history').insert({inventory_id:null,barcode:p.barcode,product_name:p.name,action:'delete',location:'all',quantity_change:-totalUnits(p),changed_by:currentUser.id});closePanel();await loadInventory()};
  let inventorySortKey='name';
  let inventorySortDirection='asc';

  function inventorySortValue(product,key){
    if(key==='total')return totalUnits(product);
    if(key==='status')return totalUnits(product)<=0?'out_of_stock':'in_stock';
    return product[key]??'';
  }

  function compareInventoryProducts(a,b){
    const aValue=inventorySortValue(a,inventorySortKey);
    const bValue=inventorySortValue(b,inventorySortKey);
    let result;
    if(typeof aValue==='number'&&typeof bValue==='number')result=aValue-bValue;
    else result=String(aValue).localeCompare(String(bValue),undefined,{numeric:true,sensitivity:'base'});
    if(result===0)result=String(a.name||'').localeCompare(String(b.name||''),undefined,{numeric:true,sensitivity:'base'});
    return inventorySortDirection==='asc'?result:-result;
  }

  function updateInventorySortHeaders(){
    document.querySelectorAll('[data-inventory-sort]').forEach(button=>{
      const active=button.dataset.inventorySort===inventorySortKey;
      button.classList.toggle('active',active);
      const th=button.closest('th');
      if(th)th.setAttribute('aria-sort',active?(inventorySortDirection==='asc'?'ascending':'descending'):'none');
    });
  }

  document.querySelectorAll('[data-inventory-sort]').forEach(button=>{
    button.addEventListener('click',()=>{
      const key=button.dataset.inventorySort;
      if(inventorySortKey===key)inventorySortDirection=inventorySortDirection==='asc'?'desc':'asc';
      else{inventorySortKey=key;inventorySortDirection='asc';}
      renderList();
    });
  });

  $('searchInput').oninput=renderList;
  $('inventoryCategoryFilter').onchange=renderList;
  $('inventoryStatusFilter').onchange=renderList;
  $('inventoryClearFilters').onclick=()=>{
    $('searchInput').value='';
    $('inventoryCategoryFilter').value='';
    $('inventoryStatusFilter').value='';
    renderList();
  };

  function renderList(){
    const q=$('searchInput').value.trim().toLowerCase();
    const category=$('inventoryCategoryFilter').value;
    const status=$('inventoryStatusFilter').value;
    const rows=inventory.filter(p=>{
      const matchesSearch=!q||[p.name,p.barcode,p.category,p.distributor].some(v=>String(v||'').toLowerCase().includes(q));
      const matchesCategory=!category||p.category===category;
      const actualStatus=totalUnits(p)<=0?'out_of_stock':'in_stock';
      const matchesStatus=!status||actualStatus===status;
      return matchesSearch&&matchesCategory&&matchesStatus;
    }).sort(compareInventoryProducts);

    updateInventorySortHeaders();
    $('inventoryResultCount').textContent=`${rows.length} of ${inventory.length} product${inventory.length===1?'':'s'}`;
    $('inventoryRows').innerHTML=rows.length?rows.map(p=>{
      const total=totalUnits(p);
      const actualStatus=total<=0?'out_of_stock':'in_stock';
      return `<tr class="inventory-row" data-id="${p.id}">
        <td class="product-cell" data-label="Product"><span class="product-name">${esc(p.name)}</span><span class="mobile-product-meta">${esc(p.barcode)}${p.category?' · '+esc(p.category):''}</span></td>
        <td class="barcode-cell" data-label="Barcode">${esc(p.barcode)}</td>
        <td class="category-cell" data-label="Category">${esc(p.category||'Uncategorized')}</td>
        <td class="distributor-cell" data-label="Distributor">${esc(p.distributor||'—')}</td>
        <td class="number-column floor-cell" data-label="Floor">${p.floorQty}</td>
        <td class="number-column backroom-cell" data-label="Backroom">${p.backroomQty}</td>
        <td class="number-column cases-cell" data-label="Cases">${p.backroomCases}</td>
        <td class="number-column total-cell" data-label="Total">${total}<span class="mobile-location">F ${p.floorQty} · B ${p.backroomQty}</span></td>
        <td class="status-cell" data-label="Status"><span class="badge ${actualStatus==='out_of_stock'?'out':'in'}">${actualStatus==='out_of_stock'?'Out':'In stock'}</span></td>
      </tr>`;
    }).join(''):'<tr><td colspan="9" class="inventory-empty">No matching products.</td></tr>';

    document.querySelectorAll('#inventoryRows .inventory-row').forEach(row=>{
      row.onclick=()=>openPanel(inventory.find(p=>p.id===row.dataset.id));
    });
  }
  function stats(filtered=inventory){return{products:filtered.length,units:filtered.reduce((s,p)=>s+totalUnits(p),0),cases:filtered.reduce((s,p)=>s+p.backroomCases,0),out:filtered.filter(p=>totalUnits(p)<=0).length,retail:filtered.reduce((s,p)=>s+totalUnits(p)*(p.price||0),0),cost:filtered.reduce((s,p)=>s+totalUnits(p)*(p.cost||0),0)}}
  function renderStats(){const s=stats();$('statTotal').textContent=s.products;$('statUnits').textContent=s.units;$('statCases').textContent=s.cases;$('statOut').textContent=s.out}
  $('exportBtn').onclick=()=>{if(!inventory.length)return toast('Nothing to export');const rows=inventory.map(p=>({'Barcode':p.barcode,'Product Name':p.name,'Price':p.price??'','Cost':p.cost??'','Category':p.category,'Distributor':p.distributor,'On Floor':p.floorQty,'Back Room':p.backroomQty,'Cases':p.backroomCases,'Units per Case':p.unitsPerCase,'Total Units':totalUnits(p),'Retail Value':totalUnits(p)*(p.price||0),'Cost Value':totalUnits(p)*(p.cost||0),'Low Stock Alert':p.lowStockAlertEnabled?'On':'Off','Low Stock Threshold':p.lowStockThreshold,'Status':p.status}));const ws=XLSX.utils.json_to_sheet(rows),wb=XLSX.utils.book_new();XLSX.utils.book_append_sheet(wb,ws,'Inventory');XLSX.writeFile(wb,`shelf-inventory-${new Date().toISOString().slice(0,10)}.xlsx`)};
  function usageCount(kind,name){
    const inv=inventory.filter(p=>(kind==='category'?p.category:p.distributor)===name).length;
    return {inventory:inv};
  }
  function renderManager(kind){
    const records=kind==='category'?categoryRecords:distributorRecords;
    const el=$(kind==='category'?'adminCategoryList':'adminDistributorList');
    if(!records.length){el.innerHTML='<div class="small-note">No entries yet.</div>';return;}
    el.innerHTML=records.map(r=>{const u=usageCount(kind,r.name);return `<div class="manager-item ${r.active?'':'inactive-row'}"><div class="manager-main"><div><div class="manager-name">${esc(r.name)}</div><div class="manager-meta">${u.inventory} live inventory product${u.inventory===1?'':'s'} · ${r.active?'Active':'Inactive'}</div></div><div class="manager-actions"><button class="mini-btn" data-manage="rename" data-kind="${kind}" data-name="${esc(r.name)}">Rename</button><button class="mini-btn" data-manage="merge" data-kind="${kind}" data-name="${esc(r.name)}">Merge</button><button class="mini-btn warn" data-manage="toggle" data-kind="${kind}" data-name="${esc(r.name)}">${r.active?'Deactivate':'Activate'}</button><button class="mini-btn danger" data-manage="remove" data-kind="${kind}" data-name="${esc(r.name)}">Remove</button></div></div></div>`}).join('');
    el.querySelectorAll('[data-manage]').forEach(b=>b.onclick=()=>openManage(b.dataset.kind,b.dataset.manage,b.dataset.name));
  }
  function openManage(kind,action,source){
    const records=kind==='category'?categoryRecords:distributorRecords, label=kind==='category'?'category':'distributor';
    manageState={kind,action,source};$('manageModal').classList.add('active');$('manageNameWrap').style.display=action==='rename'?'block':'none';$('manageTargetWrap').style.display=['merge','remove'].includes(action)?'block':'none';
    $('manageNameInput').value=action==='rename'?source:'';
    const alternatives=records.filter(r=>r.name!==source&&r.active).map(r=>r.name);
    $('manageTargetSelect').innerHTML=(action==='remove'?`<option value="">${kind==='category'?'Set as Uncategorized':'Set as None'}</option>`:'')+alternatives.map(x=>`<option value="${esc(x)}">${esc(x)}</option>`).join('');
    const count=usageCount(kind,source).inventory;
    if(action==='rename'){$('manageModalTitle').textContent=`Rename ${label}`;$('manageModalText').textContent=`Rename “${source}” everywhere it is used.`;$('manageConfirm').textContent='Rename'}
    if(action==='merge'){$('manageModalTitle').textContent=`Merge ${label}`;$('manageModalText').textContent=`Move all products from “${source}” into another ${label}, then remove “${source}”.`;$('manageConfirm').textContent='Merge'}
    if(action==='toggle'){$('manageModalTitle').textContent=`${records.find(r=>r.name===source)?.active?'Deactivate':'Activate'} ${label}`;$('manageModalText').textContent=`Inactive entries stay on existing products but no longer appear as choices for new assignments.`;$('manageConfirm').textContent=records.find(r=>r.name===source)?.active?'Deactivate':'Activate'}
    if(action==='remove'){$('manageModalTitle').textContent=`Remove ${label}`;$('manageModalText').textContent=`“${source}” is used by ${count} live inventory product${count===1?'':'s'}. Choose where those products should go before removal.`;$('manageConfirm').textContent='Remove'}
    $('manageModalNote').textContent=action==='merge'&&!alternatives.length?`Create another active ${label} before merging.`:'';
    $('manageConfirm').disabled=action==='merge'&&!alternatives.length;
  }
  function closeManage(){$('manageModal').classList.remove('active');manageState=null;$('manageConfirm').disabled=false}
  $('manageCancel').onclick=closeManage;$('manageModal').onclick=e=>{if(e.target===$('manageModal'))closeManage()};
  $('manageConfirm').onclick=async()=>{
    if(!manageState)return;const {kind,action,source}=manageState;let target=null;
    if(action==='rename'){target=$('manageNameInput').value.trim();if(!target)return toast('Enter a new name');if(target.toLowerCase()===source.toLowerCase())return closeManage()}
    if(['merge','remove'].includes(action))target=$('manageTargetSelect').value||null;
    const records=kind==='category'?categoryRecords:distributorRecords, active=records.find(r=>r.name===source)?.active!==false;
    const params={p_kind:kind,p_action:action,p_source:source,p_target:target,p_active:action==='toggle'?!active:null};
    $('manageConfirm').disabled=true;const {error}=await db.rpc('manage_reference_value',params);$('manageConfirm').disabled=false;
    if(error){toast(error.message);return}closeManage();await loadInventory();toast(`${kind==='category'?'Category':'Distributor'} updated`);
  };
  async function loadAdminUsers(){
    const {data,error}=await db.rpc('admin_list_users');
    const el=$('adminUserList');
    if(error){el.innerHTML=`<div class="small-note">User management is not installed yet. Run the V6 Supabase SQL upgrade.<br>${esc(error.message)}</div>`;return}
    adminUsers=data||[];
    const activeAdmins=adminUsers.filter(u=>u.role==='admin'&&u.is_active).length;
    el.innerHTML=adminUsers.length?adminUsers.map(u=>{
      const self=u.id===currentUser.id, lastAdmin=u.role==='admin'&&u.is_active&&activeAdmins<=1;
      const protectedUser=self||lastAdmin;
      return `<div class="user-row" data-user-id="${u.id}">
        <div class="user-email-cell">${esc(u.email||'Unknown user')}<div class="user-meta">Joined ${u.created_at?new Date(u.created_at).toLocaleDateString():'—'}${self?' · You':''}</div></div>
        <select class="user-role-select" ${protectedUser?'disabled':''}><option value="staff" ${u.role==='staff'?'selected':''}>Staff</option><option value="admin" ${u.role==='admin'?'selected':''}>Admin</option></select>
        <div class="user-status ${u.is_active?'active':'disabled'}">${u.is_active?'Active':'Disabled'}</div>
        <div class="user-actions"><button class="mini-btn user-toggle" ${protectedUser?'disabled':''}>${u.is_active?'Disable':'Enable'}</button><button class="mini-btn user-remove" ${protectedUser?'disabled':''}>Remove</button></div>
      </div>`}).join(''):'<div class="small-note">No users found.</div>';
    el.querySelectorAll('.user-role-select').forEach(sel=>sel.onchange=async()=>{
      const id=sel.closest('.user-row').dataset.userId;
      const {error}=await db.rpc('admin_set_user_role',{p_user_id:id,p_role:sel.value});
      if(error){toast(error.message);await loadAdminUsers();return}toast('Role updated');await loadAdminUsers();
    });
    el.querySelectorAll('.user-toggle').forEach(btn=>btn.onclick=async()=>{
      const row=btn.closest('.user-row'),id=row.dataset.userId,u=adminUsers.find(x=>x.id===id);
      if(!u)return;if(!confirm(`${u.is_active?'Disable':'Enable'} ${u.email}?`))return;
      const {error}=await db.rpc('admin_set_user_active',{p_user_id:id,p_active:!u.is_active});
      if(error){toast(error.message);return}toast(u.is_active?'User disabled':'User enabled');await loadAdminUsers();
    });
    el.querySelectorAll('.user-remove').forEach(btn=>btn.onclick=async()=>{
      const id=btn.closest('.user-row').dataset.userId,u=adminUsers.find(x=>x.id===id);if(!u)return;
      if(!confirm(`Permanently remove ${u.email}? Their inventory history will remain.`))return;
      const typed=prompt(`Type REMOVE to permanently delete ${u.email}`);if(typed!=='REMOVE')return;
      const {error}=await db.rpc('admin_delete_user',{p_user_id:id});
      if(error){toast(error.message);return}toast('User removed');await loadAdminUsers();
    });
  }
  function localDateValue(date){
    const year=date.getFullYear(),month=String(date.getMonth()+1).padStart(2,'0'),day=String(date.getDate()).padStart(2,'0');
    return `${year}-${month}-${day}`;
  }
  function dateRangeDays(start,end){
    const a=new Date(`${start}T00:00:00`),b=new Date(`${end}T00:00:00`);
    return Math.floor((b-a)/86400000)+1;
  }
  function initializeHistoryDates(){
    const today=localDateValue(new Date());
    if(!$('historyStartDate').value)$('historyStartDate').value=today;
    if(!$('historyEndDate').value)$('historyEndDate').value=today;
  }
  function validateHistoryRange(){
    initializeHistoryDates();
    const start=$('historyStartDate').value,end=$('historyEndDate').value,days=dateRangeDays(start,end);
    if(!start||!end)return {valid:false,message:'Choose both dates.'};
    if(days<1)return {valid:false,message:'End date must be on or after the start date.'};
    if(days>93)return {valid:false,message:'Choose a date range of no more than 3 months.'};
    const allOption=$('historyPageSizeAll');
    allOption.disabled=days>5;
    if(days>5&&$('historyPageSize').value==='all')$('historyPageSize').value='50';
    return {valid:true,start,end,days};
  }
  async function loadHistory(){
    if(!isAdmin())return;
    const range=validateHistoryRange();
    if(!range.valid){$('historyFilterMessage').textContent=range.message;return;}
    const pageValue=$('historyPageSize').value;
    const pageSize=pageValue==='all'?null:Number(pageValue);
    const startIso=new Date(`${range.start}T00:00:00`).toISOString();
    const endDate=new Date(`${range.end}T00:00:00`);endDate.setDate(endDate.getDate()+1);
    const endIso=endDate.toISOString();
    let countQuery=db.from('inventory_history').select('id',{count:'exact',head:true}).gte('changed_at',startIso).lt('changed_at',endIso);
    const {count,error:countError}=await countQuery;
    if(countError){$('historyFilterMessage').textContent=countError.message;return;}
    historyTotal=count||0;
    const totalPages=pageSize?Math.max(1,Math.ceil(historyTotal/pageSize)):1;
    historyPage=Math.min(Math.max(1,historyPage),totalPages);
    let query=db.from('inventory_history').select('*').gte('changed_at',startIso).lt('changed_at',endIso).order('changed_at',{ascending:false});
    if(pageSize){const from=(historyPage-1)*pageSize;query=query.range(from,from+pageSize-1);}
    const {data,error}=await query;
    if(error){$('historyFilterMessage').textContent=error.message;return;}
    $('historyRows').innerHTML=(data||[]).map(h=>`<tr><td>${new Date(h.changed_at).toLocaleString()}</td><td>${esc(h.product_name||h.barcode)}</td><td>${esc(h.action)}</td><td>${h.quantity_change>0?'+':''}${h.quantity_change} ${esc(h.location||'')}</td><td>${esc(h.changed_by_email||'User')}</td></tr>`).join('')||'<tr><td colspan="5">No history found for this date range.</td></tr>';
    $('historyPageInfo').textContent=pageSize?`Page ${historyPage} of ${totalPages}`:`${historyTotal} rows`;
    $('historyPreviousButton').disabled=!pageSize||historyPage<=1;
    $('historyNextButton').disabled=!pageSize||historyPage>=totalPages;
    $('historyFilterMessage').textContent=`${historyTotal} record${historyTotal===1?'':'s'} · ${range.days} day${range.days===1?'':'s'}`+(range.days>5?' · “All” is available for ranges up to 5 days.':'');
  }
  $('historyApplyDateButton').onclick=()=>{historyPage=1;loadHistory()};
  $('historyTodayButton').onclick=()=>{const today=localDateValue(new Date());$('historyStartDate').value=today;$('historyEndDate').value=today;historyPage=1;loadHistory()};
  $('historyPageSize').onchange=()=>{historyPage=1;loadHistory()};
  $('historyPreviousButton').onclick=()=>{if(historyPage>1){historyPage--;loadHistory()}};
  $('historyNextButton').onclick=()=>{historyPage++;loadHistory()};
  async function renderAdmin(){if(!isAdmin())return;const s=stats();$('dashProducts').textContent=s.products;$('dashUnits').textContent=s.units;$('dashRetail').textContent=money.format(s.retail);$('dashCost').textContent=money.format(s.cost);$('dashProfit').textContent=money.format(s.retail-s.cost);renderManager('category');renderManager('distributor');await loadAdminUsers();const low=inventory.filter(p=>p.lowStockAlertEnabled&&p.lowStockThreshold>0&&totalUnits(p)<=p.lowStockThreshold).sort((a,b)=>(b.lowStockThreshold-totalUnits(b))-(a.lowStockThreshold-totalUnits(a)));$('lowStockList').innerHTML=low.length?low.map(p=>{const current=totalUnits(p),needed=Math.max(0,p.lowStockThreshold-current);return`<div class="alert-item"><div class="alert-name">${esc(p.name)}<small>${esc(p.barcode)}${p.category?' · '+esc(p.category):''}</small></div><div class="alert-stock"><strong>${current} / ${p.lowStockThreshold}</strong><small>Current / threshold</small></div><div class="alert-short">Need ${needed} more</div><div class="alert-extra">${esc(p.distributor||'No distributor')}</div><button class="mini-btn alert-open" data-low-id="${p.id}">Open</button></div>`}).join(''):'<div class="small-note">No low-stock products.</div>';document.querySelectorAll('[data-low-id]').forEach(b=>b.onclick=()=>openPanel(inventory.find(p=>p.id===b.dataset.lowId)));renderReports();initializeHistoryDates();await loadHistory()}
  function renderReports(){const cat=$('reportCategory').value,dist=$('reportDistributor').value,filtered=inventory.filter(p=>(!cat||p.category===cat)&&(!dist||p.distributor===dist)),groups={};filtered.forEach(p=>{const k=p.category||'Uncategorized';(groups[k]??=[]).push(p)});$('reportRows').innerHTML=Object.entries(groups).sort().map(([k,v])=>{const s=stats(v);return`<tr><td>${esc(k)}</td><td>${s.products}</td><td>${s.units}</td><td>${money.format(s.retail)}</td><td>${money.format(s.cost)}</td></tr>`}).join('')||'<tr><td colspan="5">No report data.</td></tr>'}
  $('reportCategory').onchange=renderReports;$('reportDistributor').onchange=renderReports;
  $('adminAddCategory').onclick=async()=>{await addList('category',$('adminCategoryName').value);$('adminCategoryName').value='';if(isAdmin())renderAdmin()};$('adminAddDistributor').onclick=async()=>{await addList('distributor',$('adminDistributorName').value);$('adminDistributorName').value='';if(isAdmin())renderAdmin()};
  $('catalogImportBtn').onclick=async()=>{if(!isAdmin())return;const file=$('catalogFile').files[0];if(!file){toast('Choose a Clover Excel file');return}$('catalogImportStatus').textContent='Reading workbook…';try{const buf=await file.arrayBuffer(),book=XLSX.read(buf),sheet=book.Sheets['Items']||book.Sheets[book.SheetNames[0]],rows=XLSX.utils.sheet_to_json(sheet,{defval:''}),valid=new Map();for(const r of rows){const barcode=normalizeBarcode(r['Product Code']),price=Number(r['Price']);if(!barcode||!Number.isFinite(price)||price<0.99||String(r['Hidden']).toLowerCase()==='yes')continue;valid.set(barcode,{barcode,product_name:String(r['Name']||'').trim(),price,cost:Number(r['Cost'])||0,category:String(r['Modifier Groups']||'').trim()||null,distributor:null,updated_at:new Date().toISOString()})}const all=[...valid.values()],chunk=400;for(let i=0;i<all.length;i+=chunk){$('catalogImportStatus').textContent=`Importing ${Math.min(i+chunk,all.length)} of ${all.length}…`;const {error}=await db.from('product_catalog').upsert(all.slice(i,i+chunk),{onConflict:'barcode'});if(error)throw error}const cats=[...new Set(all.map(x=>x.category).filter(Boolean))].map(name=>({name,created_by:currentUser.id}));if(cats.length)await db.from('categories').upsert(cats,{onConflict:'name'});$('catalogImportStatus').textContent=`Imported or updated ${all.length} catalog products. Live inventory was not overwritten.`;await loadLists()}catch(e){$('catalogImportStatus').textContent=`Import failed: ${e.message}`}};
  $('camBtn').onclick=()=>camRunning?stopCamera():startCamera();function startCamera(){$('reader').style.display='block';html5QrCode=new Html5Qrcode('reader');html5QrCode.start({facingMode:'environment'},{fps:10,qrbox:{width:240,height:140}},t=>{stopCamera();handleScan(t)},()=>{}).then(()=>{camRunning=true;$('camBtn').textContent='Turn off'}).catch(e=>{$('camMsg').style.display='block';$('camMsg').textContent='Camera unavailable. Use the scanner input instead.'})}function stopCamera(){if(html5QrCode&&camRunning)html5QrCode.stop().then(()=>{html5QrCode.clear();$('reader').style.display='none';$('camBtn').textContent='Turn on';camRunning=false})}

})();
